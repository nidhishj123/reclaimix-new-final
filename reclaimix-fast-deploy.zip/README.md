# ReclaimIX — Fast Deploy (Hackathon Edition)

A single Vercel project: static HTML frontend + `/api` serverless functions,
talking directly to MongoDB. No build step, no framework detection issues,
no separate backend host needed.

## Deploy in 3 steps

1. Push this folder to a new GitHub repo (root of the repo = root of this folder).
2. Go to vercel.com/new, import the repo. Leave all settings as default
   (Root Directory = `.` / blank — do NOT set it to a subfolder this time).
3. Before or right after the first deploy, add one environment variable:
   - `MONGO_URI` = your MongoDB Atlas connection string
   (Settings → Environment Variables → add → redeploy)

That's it. Visit your `.vercel.app` URL.

- `/` — the app UI
- `/api/health` — confirms MongoDB is reachable (visit this first if the UI shows a DB error)
- `/api/items` — GET list / POST create, backed by MongoDB directly

## If /api/health shows an error

- Most common cause: MongoDB Atlas → Network Access doesn't allow `0.0.0.0/0`.
- Second most common: `MONGO_URI` has an unescaped special character in the password.
- Confirm the env var was added *before* the deploy you're testing — env vars only
  apply to deployments triggered after they're saved.
