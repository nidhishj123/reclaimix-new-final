const { getDb } = require("./_db");

module.exports = async (req, res) => {
  try {
    const db = await getDb();
    await db.command({ ping: 1 });
    res.status(200).json({ success: true, message: "MongoDB connected", db: db.databaseName });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
