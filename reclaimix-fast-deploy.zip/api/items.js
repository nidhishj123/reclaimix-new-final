const { getDb } = require("./_db");

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.status(200).end();
    return;
  }

  try {
    const db = await getDb();
    const items = db.collection("items");

    if (req.method === "GET") {
      const results = await items.find({}).sort({ createdAt: -1 }).limit(100).toArray();
      res.status(200).json({ success: true, items: results });
      return;
    }

    if (req.method === "POST") {
      const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
      const { title, description, type, location, contact } = body;

      if (!title || !type) {
        res.status(400).json({ success: false, message: "title and type are required" });
        return;
      }

      const doc = {
        title,
        description: description || "",
        type, // "lost" or "found"
        location: location || "",
        contact: contact || "",
        createdAt: new Date(),
      };

      const result = await items.insertOne(doc);
      res.status(201).json({ success: true, item: { _id: result.insertedId, ...doc } });
      return;
    }

    res.status(405).json({ success: false, message: "Method not allowed" });
  } catch (err) {
    console.error("API /items error:", err);
    res.status(500).json({ success: false, message: err.message });
  }
};
